
package service;



import java.util.List;

import dao.ProductDAO;
import dao.ProductDAOImplementation;
import entities.Product;
//In The SERVICE
public class ProductServiceImplementation implements ProductService 
{
        ProductDAO productDAO = new ProductDAOImplementation();
//	ProductDAO productDAO;
        
//        public void createProductService(Product product) {
//                                        productDAO.insertProduct(product);
//        }
        
//        
//        public Product findProductService(int productNumber) {     
//                        return productDAO.selectAllProducts(productNumber);
//        }
//        
        
        public List<Product> findProductsService() {
                        return productDAO.selectAllProducts();
        }
//        
//        
//        public void modifyProductService(Product product) {
//                        productDAO.updateProduct(product);
//        }
//        
//        
//        public void removeProductService(int productNumber) {
//                        productDAO.deleteProduct(productNumber);
//        }
	
	
        
//        public ProductServiceImplementation(ProductDAO productDAO) {
//            this.productDAO = productDAO;
//        }

        @Override
        public List<Product> getAllProducts() {
            return productDAO.selectAllProducts();
        }

        
}
