package dao;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entities.Product;

public class ProductDAOImplementation implements ProductDAO {

	Connection conn ; //GLOBAL 
	
	public ProductDAOImplementation() {
		try {
			//1. Load the Driver
			System.out.println("Trying to load the driver...");
				DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver loaded....");
			
			//2. Acquire the connection
			System.out.println("Trying to connect....");
			conn = 	DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
			System.out.println("Connected : "+ conn);
			
						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
////	@Override
////	public void insertProduct(Product product) {
////		//3. make a desired statement (insert/update/delete/select)
////		
////		try {
////			PreparedStatement pst = 
////					conn.prepareStatement("INSERT INTO PRODUCTS VALUES (?,?,?)");
////			
////			pst.setInt(1, product.getProductNumber());
////			pst.setString(3, product.getProductName());
////			pst.setString(2,product.getProductLocation());
////			
////			System.out.println("PreparedStatement is created : "+ pst);
////			
////			//4. execute that statement //  UR TABLENAME IS MYMYPRODUCTS
////			int rows = pst.executeUpdate();
////			
////			System.out.println("Rows created : "+rows);
////		} catch (SQLException e) {
////			// TODO Auto-generated catch block
////			e.printStackTrace();
////		}
////	
////	}
//
//	@Override
//	public Product selectProduct(int productNumber) {
//		
//		Product productObj =null;
//		try {
//			
//			Statement statement = conn.createStatement();
//			System.out.println("Statement is created : "+ statement);
//			
//			//4. execute that statement //  UR TABLENAME IS MYMYPRODUCTS
//			ResultSet result = statement.executeQuery("SELECT * FROM PRODUCTS WHERE productNO="+productNumber);
//			
//			//5. process teh result if any
//			if(result.next()) {
//				productObj = new Product(); //blank object
//				
//				productObj.setProductNumber(result.getInt(1));
//				productObj.setProductLocation(result.getString(2));
//				productObj.setProductName(result.getString(3));
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return productObj;
//	}

	@Override
	public List<Product> selectAllProducts() {
		
		List<Product> productList = new ArrayList<Product>();
		try {
			
			 
			Statement statement = conn.createStatement();
			System.out.println("Statement is created : "+ statement);
			
			//4. execute that statement //  UR TABLENAME IS MYMYPRODUCTS
			ResultSet result = statement.executeQuery("SELECT * FROM PRODUCTS");
			
			//5. process teh result if any
			while(result.next()) {
				Product productObj = new Product(); //blank object
				
				productObj.setProduct_id(result.getInt(1));
				productObj.setProduct_name(result.getString(2));
				productObj.setPrice(result.getDouble(3));
				productObj.setDescription(result.getString(4));
				productObj.setCategory(result.getString(5));
				productObj.setQuantity_in_stock(result.getInt(6));
				productObj.setBrand(result.getString(7));
				productObj.setImage_url(result.getString(8));
				productObj.setRating(result.getDouble(9));
				productList.add(productObj); // add this object to the LIST 
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return productList;
	}

//	@Override
//	public void updateProduct(Product product) {
//		//3. make a desired statement (insert/update/delete/select)
//		
//				try {
//					PreparedStatement pst = 
//							conn.prepareStatement("UPDATE PRODUCTS set dname=?, loc=? where productno=?");
//					
//					
//					pst.setString(1, product.getProductName()); //SET dname=?
//					pst.setString(2,product.getProductLocation()); //SET loc=?
//					pst.setInt(3, product.getProductNumber()); //WHERE productno=?
//
//					
//					System.out.println("PreparedStatement is created : "+ pst);
//					
//					//4. execute that statement //  UR TABLENAME IS MYMYPRODUCTS
//					int rows = pst.executeUpdate();
//					
//					System.out.println("Row MODIFIED : "+rows);
//				} catch (SQLException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//	}
//
//	@Override
//	public void deleteProduct(int productNumber) {
//		//3. make a desired statement (insert/update/delete/select)
//		
//		try {
//			PreparedStatement pst = 
//					conn.prepareStatement("DELETE FROM PRODUCTS where productno=?");
//			
//			pst.setInt(1, productNumber); //WHERE productno=?
//
//			
//			System.out.println("PreparedStatement is created : "+ pst);
//			
//			//4. execute that statement //  UR TABLENAME IS MYMYPRODUCTS
//			int rows = pst.executeUpdate();
//			
//			System.out.println("Row DELETED : "+rows);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//
//	@Override
//	public void insertProduct(Product product) {
//		// TODO Auto-generated method stub
//		
//	}
//
}