package dao;

import java.util.List;

import entities.Product;

//II. POJI
public interface ProductDAO { //POJI as per the POJO

//	public void insertProduct(Product dept); //C
//	public Product selectProduct(int deptNumber);//R
	public List<Product> selectAllProducts(); //RA
//	public void updateProduct(Product dept); //U
//	public void deleteProduct(int deptNumber);  //D
	
}