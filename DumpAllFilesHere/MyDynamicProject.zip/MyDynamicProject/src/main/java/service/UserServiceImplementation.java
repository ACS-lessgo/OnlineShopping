package service;

import java.util.List;
import dao.UserDAO;
import dao.UserDAOImplementation;
import entities.User;

public class UserServiceImplementation implements UserService 
{

    private UserDAO userDAO = new UserDAOImplementation();

    @Override
    public void createUserService(User user) 
    {
        userDAO.insertUser(user);
    }

    @Override
    public User findUserService(int userNumber) 
    {
        return userDAO.selectUser(userNumber);
    }

    @Override
    public List<User> findUserService() 
    {
        return userDAO.selectUsers();
    }

    @Override
    public void modifyUserService(User user) 
    {
        userDAO.updateUser(user);
    }

    @Override
    public void removeUserService(int userNumber) 
    {
        userDAO.deleteUser(userNumber);
    }
}
