package service;

import java.util.List;

import entities.User;

public interface UserService 
{
void createUserService(User user);
User findUserService(int userNumber);
List<User> findUserService();
void modifyUserService(User user);
void removeUserService(int userNumber);
}
