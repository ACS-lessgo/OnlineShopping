package dao;

import java.util.List;

import entities.User;

public interface UserDAO 
{
	public void insertUser(User user);
	public User selectUser(int UserNumber);
	public List<User> selectUsers();
	public void updateUser(User user);
	public void deleteUser(int UserNumber);
	
}
