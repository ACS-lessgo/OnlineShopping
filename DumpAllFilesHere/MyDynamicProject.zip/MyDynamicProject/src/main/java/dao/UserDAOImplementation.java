package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entities.User;

public class UserDAOImplementation implements UserDAO
{

    Connection conn;

    public UserDAOImplementation() 
    {
    	try {
			//1. Load the Driver
			System.out.println("Trying to load the driver...");
				DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver loaded....");
			
			//2. Acquire the connection
			System.out.println("Trying to connect....");
			conn = 	DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
			System.out.println("Connected : "+ conn);
			
						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @Override
    public void insertUser(User user) {
        try {
            PreparedStatement pst = conn.prepareStatement(
                    "INSERT INTO User (userId, userName, userEmail, userPhone, userAddress, userPostalCode) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

            pst.setInt(1, user.getUserId());
            pst.setString(2, user.getUserName());
            pst.setString(3, user.getUserEmail());
            pst.setString(4, user.getUserPhone());
            pst.setString(5, user.getUserAddress());
            pst.setString(6, user.getUserPostalCode());
          

            pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public User selectUser(int userId) 
    {
        User user = null;
        try {
            PreparedStatement pst = conn.prepareStatement("SELECT * FROM User WHERE userId = ?");
            pst.setInt(1, userId);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                user = new User();
                user.setUserId(rs.getInt("userId"));
                user.setUserName(rs.getString("userName"));
                user.setUserEmail(rs.getString("userEmail"));
                user.setUserPhone(rs.getString("userPhone"));
                user.setUserAddress(rs.getString("userAddress"));
                user.setUserPostalCode(rs.getString("userPostalCode"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }

    @Override
    public List<User> selectUsers() {
        List<User> userList = new ArrayList<>();
        try {
            PreparedStatement pst = conn.prepareStatement("SELECT * FROM User");

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                User user = new User();
                user.setUserId(rs.getInt("userId"));
                user.setUserName(rs.getString("userName"));
                user.setUserEmail(rs.getString("userEmail"));
                user.setUserPhone(rs.getString("userPhone"));
                user.setUserAddress(rs.getString("userAddress"));
                user.setUserPostalCode(rs.getString("userPostalCode"));
                userList.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userList;
    }

    @Override
    public void updateUser(User user) {
        try {
            PreparedStatement pst = conn.prepareStatement(
                    "UPDATE User SET userName=?, userEmail=?, userPassword=?, userPhone=?, userAddress=?, userPostalCode=?, userIsVerified=? "
                    + "WHERE userId=?");

            pst.setString(1, user.getUserName());
            pst.setString(2, user.getUserEmail());
            pst.setString(3, user.getUserPhone());
            pst.setString(4, user.getUserAddress());
            pst.setString(5, user.getUserPostalCode());
            pst.setInt(6, user.getUserId());

            pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteUser(int userId) {
        try {
            PreparedStatement pst = conn.prepareStatement("DELETE FROM User WHERE userId = ?");
            pst.setInt(1, userId);

            pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
