package entities; //1. package

//POJO as per the DEPT10 table's structure

//2. public 
public class Product { //I. POJO
	//4. it must have private data as per the table's structure
	private int productId; 
	private String productName; 
	private String productDescription;
	private String productCategory;
	private int productQuantity;
	private String ProductImage;
	private double ProductRating;
	private double productPrice; 
	private String Brand;
	
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public String getBrand() {
		return Brand;
	}
	public void setBrand(String brand) {
		Brand = brand;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int prodcutQuantity) {
		this.productQuantity = prodcutQuantity;
	}
	public String getProductImage() {
		return ProductImage;
	}
	public void setProductImage(String productImage) {
		ProductImage = productImage;
	}
	public double getProductRating() {
		return ProductRating;
	}
	public void setProductRating(double productRating) {
		ProductRating = productRating;
	} 
	
	



	
	
	
}
