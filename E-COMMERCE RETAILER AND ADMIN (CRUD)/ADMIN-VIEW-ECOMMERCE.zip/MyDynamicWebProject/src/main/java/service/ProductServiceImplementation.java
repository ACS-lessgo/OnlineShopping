package service;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import dao.ProductDAO;
import dao.ProductDAOImplementation;
import dao.ProductDAO;
import dao.ProductDAOImplementation;
import entities.Product;
import entities.Product;
//In The SERVICE
public class ProductServiceImplementation implements ProductService {
	ProductDAO prodDAO = new ProductDAOImplementation();
	@Override
	public void createProductService(Product product) {
		// TODO Auto-generated method stub
		prodDAO.insertProduct(product);
		
	}
 
	@Override
	public Product findProductService(int productId) {
		// TODO Auto-generated method stub
		return prodDAO.selectProduct(productId) ;
	}

	@Override
	public List<Product> findProductsService() {
		// TODO Auto-generated method stub
		return prodDAO.selectProducts() ;
	}

	@Override
	public void modifyProductService(Product product) {
		// TODO Auto-generated method stub
		 prodDAO.updateProduct(product);
		
	}

	@Override
	public void removeProductService(int productId) {
		// TODO Auto-generated method stub
		prodDAO.deleteProduct(productId);
		
	}

    public List<Product> sortProductsByCategory() {
        List<Product> productList = findProductsService();

        Collections.sort(productList, new Comparator<Product>() {
            @Override
            public int compare(Product product1, Product product2) {
                return product1.getProductCategory().compareTo(product2.getProductCategory());
            }
        });

        return productList;
    }

	@Override
	public List<Product> sortProductsByRating() {
		List<Product> productList = findProductsService();

        Collections.sort(productList, new Comparator<Product>() {
            @Override
            public int compare(Product product1, Product product2) {
                return Double.compare(product2.getProductRating(), product1.getProductRating());
            }
        });

        return productList;
	}

	@Override
	public List<Product> sortProductsByPrice() {
        List<Product> productList = findProductsService();

        Collections.sort(productList, new Comparator<Product>() {
            @Override
            public int compare(Product product1, Product product2) {
                return Double.compare(product1.getProductPrice(), product2.getProductPrice());
            }
        });

        return productList;
	}
}
