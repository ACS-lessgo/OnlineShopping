package service;

import java.util.List;

//import entities.Department;
import entities.Product;

public interface ProductService {
	
	void createProductService(Product product);
	Product findProductService(int produtId);
	List<Product> findProductsService();
	void modifyProductService(Product product);
	void removeProductService(int productId);
    List<Product> sortProductsByCategory();
    List<Product> sortProductsByRating();
    List<Product> sortProductsByPrice();
}
