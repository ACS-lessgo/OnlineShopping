package service;

import java.util.List;

import entities.User;

public interface UserService {
	
	void createUserService(User user);
	User findUserService(int userId);
	List<User> findUsersService();
	void modifyUserService(User user);
	void removeUserService(int userId);
	
}
