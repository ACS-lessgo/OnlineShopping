package service;

import java.util.List;


import dao.UserDAOImplementation;
import dao.UserDAO;
import entities.User;


public class UserServiceImplementation implements UserService {
	UserDAO userDAO = new UserDAOImplementation();
	public UserServiceImplementation() {
		// TODO Auto-generated constructor stub
		
	}

	@Override
	public void createUserService(User user) {
		// TODO Auto-generated method stub
		userDAO.insertUser(user);
	}

	@Override
	public User findUserService(int userId) {
		// TODO Auto-generated method stub
		return userDAO.selectUser(userId) ;
	}

	@Override
	public List<User> findUsersService() {
		// TODO Auto-generated method stub
		return userDAO.selectUsers() ;
	}

	@Override
	public void modifyUserService(User user) {
		// TODO Auto-generated method stub
		userDAO.updateUser(user);
		
	}

	@Override
	public void removeUserService(int userId) {
		// TODO Auto-generated method stub
		userDAO.deleteUser(userId);
	}

}
