package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import entities.User;

public class UserDAOImplementation implements UserDAO {
	Connection conn;
	public UserDAOImplementation() {
		// TODO Auto-generated constructor stub
		try {
			//1. Load the Driver
			System.out.println("Trying to load the driver...");
				DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver loaded....");
			
			//2. Acquire the connection
			System.out.println("Trying to connect....");
			conn = 	DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
			System.out.println("Connected : "+ conn);
			
						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void insertUser(User user) {
		//3. make a desired statement (insert/update/delete/select)
		
		try {
			PreparedStatement pst = 
					conn.prepareStatement("INSERT INTO USER VALUES (?,?,?,?,?,?)");
			
			pst.setInt(1,user.getUserId());
			pst.setString(2, user.getUserName());
			pst.setString(3, user.getUserEmail());
			pst.setString(4, user.getUserPhoneNumber());
			pst.setString(5,user.getUserAddress());
			pst.setInt(6, user.getUserPostalCode());

			
			System.out.println("PreparedStatement is created : "+ pst);
			
			//4. execute that statement //  UR TABLENAME IS MYDEPT120
			int rows = pst.executeUpdate();
			
			System.out.println("Rows created : "+rows);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	public User selectUser(int userNumber) {
		
		User userObj =null;
		try {
			
			Statement statement = conn.createStatement();
			System.out.println("Statement is created : "+ statement);
			
			//4. execute that statement //  UR TABLENAME IS MYDEPT120
			ResultSet result = statement.executeQuery("SELECT * FROM USER WHERE USERID="+userNumber);
			
			//5. process the result if any
			if(result.next()) {
				userObj = new User(); //blank object
				
				userObj.setUserId(result.getInt(1));
				userObj.setUserName(result.getString(2));
				userObj.setUserEmail(result.getString(3));
				userObj.setUserAddress(result.getString(5));
				userObj.setUserPhoneNumber(result.getString(4));
				userObj.setUserPostalCode(result.getInt(6));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userObj;
	}
	
	
public List<User> selectUsers() {
		
		List<User> userList = new ArrayList<User>();
		try {
			
			Statement statement = conn.createStatement();
			System.out.println("Statement is created : "+ statement);
			
			//4. execute that statement //  UR TABLENAME IS MYDEPT120
			ResultSet result = statement.executeQuery("SELECT * FROM USER");
			
			//5. process teh result if any
			while(result.next()) {
				User userObj = new User(); //blank object
				userObj.setUserId(result.getInt(1));
				userObj.setUserName(result.getString(2));
				userObj.setUserEmail(result.getString(3));
				userObj.setUserAddress(result.getString(5));
				userObj.setUserPhoneNumber(result.getString(4));
				userObj.setUserPostalCode(result.getInt(6));

				userList.add(userObj); // add this object to the LIST 
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userList;
	}

public void updateUser(User user) {
	//3. make a desired statement (insert/update/delete/select)
	
			try {
				PreparedStatement pst = 
						conn.prepareStatement("UPDATE USER SET USERADDRESS=?,USERPOSTALCODE=?, USERNAME=?, USEREMAIL=?, USERPHONE=? WHERE USERID=?"
);
				
				
				pst.setInt(6,user.getUserId());
				pst.setString(3, user.getUserName());
				pst.setString(4, user.getUserEmail());
				pst.setString(5, user.getUserPhoneNumber());
				pst.setString(1,user.getUserAddress());
				pst.setInt(2, user.getUserPostalCode());

				
				System.out.println("PreparedStatement is created : "+ pst);
				
				//4. execute that statement //  UR TABLENAME IS MYDEPT120
				int rows = pst.executeUpdate();
				
				System.out.println("Row MODIFIED : "+rows);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
}
public void deleteUser(int userID) {
	//3. make a desired statement (insert/update/delete/select)
	
	try {
		PreparedStatement pst = 
				conn.prepareStatement("DELETE FROM USER WHERE USERID=?");
		
		pst.setInt(1, userID); //WHERE deptno=?

		
		System.out.println("PreparedStatement is created : "+ pst);
		
		//4. execute that statement //  UR TABLENAME IS MYDEPT120
		int rows = pst.executeUpdate();
		
		System.out.println("Row DELETED : "+rows);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}


}
