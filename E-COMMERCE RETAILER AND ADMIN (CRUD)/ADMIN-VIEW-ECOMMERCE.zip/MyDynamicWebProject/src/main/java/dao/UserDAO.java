package dao;
import entities.User;
import java.util.List;


public interface UserDAO {
	public void insertUser(User user); //C
	public User selectUser(int userNumber);//R
	public List<User> selectUsers(); //RA
	public void updateUser(User user); //U
	public void deleteUser(int userNumber); //D
}
